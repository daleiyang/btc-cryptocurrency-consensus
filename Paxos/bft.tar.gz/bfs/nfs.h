#ifndef _NFS_H
#define _NFS_H 1

#define NFS_PROGRAM		100003
#define NFS_VERSION		2
#define NFSD_PROXY_PORT 3500

#endif // _NFS_H
