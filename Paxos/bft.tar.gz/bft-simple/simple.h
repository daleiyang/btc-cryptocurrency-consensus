#ifndef _simple_h
#define _simple_h 1

static const int Simple_size = 4096;

#endif // _simple_h
