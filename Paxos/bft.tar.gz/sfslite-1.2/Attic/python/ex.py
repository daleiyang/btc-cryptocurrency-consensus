
import sfs.setup.rpcc

r = sfs.setup.rpcc.rpccompiler (rpcc='/disk/rael/max/d33/sfs/rpcc/rpcc')

r.compile_all (['ex1/ex1.x'], None)

