
#ifndef _LIBTAME_TYPEDEFS_H_
#define _LIBTAME_TYPEDEFS_H_

typedef event<bool>::ref evb_t;
typedef event<int>::ref evi_t;
typedef event<>::ref evv_t;
typedef event<str>::ref evs_t;

#endif /* _LIBTAME_TYPEDEFS_H_ */
