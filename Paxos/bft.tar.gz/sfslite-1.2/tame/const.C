
#include "tame.h"

const char *cceoc_argname = "callercv";
